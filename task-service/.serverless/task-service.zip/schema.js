const { gql } = require("apollo-server-express");
const { GraphQLError } = require("graphql");
const db = require("./models/db");

const typeDefs = gql`
  type Query {
    getTasksByDay(date: String!, user_id: Int): [Task]
    getAllTasks(user_id: Int): [Task]
  }

  type Mutation {
    createTask(task: TaskInput): Task!
    updateTask(task: UpdateTaskInput): Task
    deleteTask(id: ID!): Task
    completeTask(id: ID!, onTime: Boolean!): Task
    pushTask(id: ID!, newStartTime: String!, newEndTime: String!, newTimeOfDay: Int!): Task
  }


  input TaskInput {
    id: ID
    task_name: String
    task_description: String
    category: Int
    date: String
    time_start: String
    time_finished: String
    time_of_day: Int
    completed: Boolean
    completed_on_time: Int
    user_id: Int
  }

  input UpdateTaskInput {
    id: ID
    task_name: String
    task_description: String
    category: Int
    date: String
    time_start: String
    time_finished: String
    time_of_day: Int
    completed: Boolean
    completed_on_time: Int
  }

  extend type User @key(fields: "id") {
    id: ID! @external
  }



  type Task {
    id: ID!
    task_name: String
    task_description: String
    category: Int
    date: String
    time_start: String
    time_finished: String
    time_of_day: Int
    completed: Boolean
    completed_on_time: Int
    user_id: Int
    user: User
  }
`;

const resolvers = {
  Task: {
    user: async (parent, args) => {
      //Find User from UserTable using parent.userID
      const { user_id } = parent;
      const user = await db.query("SELECT * FROM users WHERE id = $1;", [
        user_id,
      ]);
      return user.rows[0];
    },
  },
  Query: {
    getTasksByDay: async (_, args) => {
      // grab day from args and use to get tasks for the day
      const { date, user_id } = args; //"1670522400000"
      // date: '2022-12-11'   1day = 86.4 mil ms
      const startOfDay = new Date(date).getTime();
      const endOfDay = startOfDay + 86400000;
      const params = [startOfDay - 1, endOfDay, user_id];
      const task = await db.query(
        "SELECT * FROM tasks WHERE date > $1 AND date < $2 AND user_id = ($3) ORDER BY time_start ASC;",
        params
      );
      return task.rows;
    },
    getAllTasks: async (_, args) => {
      const { user_id } = args;
      const task = await db.query("SELECT * FROM tasks WHERE user_id = ($1) AND completed_on_time = 1;", [user_id]);
      return task.rows;
    },
    getDataML: async (_, args) => {
      const { user_id } = args;
      //check in the metrics table if there is a row that matches the user_id
      //if there is, we will just fetch and return that row
      const check = await db.query("SELECT * FROM metrics WHERE user_id = ($1);", [user_id]);
      //if there isnt, we make a call to the python service to generate the relevant data and insert into the DB and return.
      return check.rows.length !== 0 ? {recommendations: check.rows[0].recommendations, metrics: JSON.parse(check.rows[0].metrics)} : null
      // let dataML;
      // if (check.rows.length == 0) {
      //   const res = await axios.post(`http://127.0.0.1:5000/recommend/${user_id}`);
      //   dataML = res.data;
      //   await db.query('INSERT INTO metrics (recommendations, metrics, user_id) VALUES ($1, $2, $3)', [dataML.recommendations, JSON.stringify(dataML.metrics), user_id])
      // } else {
      //   dataML = {recommendations: check.rows[0].recommendations, metrics: JSON.parse(check.rows[0].metrics)}
      // }
      
      // return dataML
    },
    getLastGeneration: async (_, args) => {
      const { user_id } = args;
      console.log("get last gen args: ", args)
      const lastGeneration = await db.query("SELECT lastgeneration FROM users WHERE ID = ($1)", [user_id])
      console.log("last generation: ", lastGeneration.rows[0].lastgeneration)
      return lastGeneration.rows[0].lastgeneration;
    }
  },
  Mutation: {
    createTask: async (_, args) => {
      // post req to Task db table
      const {
        task_name,
        task_description,
        category,
        date,
        time_start,
        time_finished,
        time_of_day,
        completed,
        completed_on_time,
        user_id,
      } = args.task;

      const newTask = await db.query(
        "INSERT INTO tasks (task_name, task_description, category, date, time_start, time_finished, time_of_day, completed, completed_on_time, user_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *;",
        [
          task_name,
          task_description,
          category ?? 0,
          date,
          time_start,
          time_finished,
          time_of_day,
          completed,
          completed_on_time ?? 0,
          user_id,
        ]
      );
      return newTask.rows[0];
    },
    updateTask: async (_, args) => {
      const {
        id,
        task_name,
        task_description,
        category,
        date,
        time_start,
        time_finished,
        time_of_day,
        completed,
        completed_on_time
      } = args.task;

      const queryString = `UPDATE tasks SET task_name = $1, task_description = $2, category = $3, date = $4, time_start = $5, time_finished = $6, time_of_day = $7, completed = $8, completed_on_time = $9 WHERE id = $10 RETURNING *;`;
      const updatedTask = await db.query(queryString, [
        task_name,
        task_description,
        category ?? 0,
        date,
        time_start,
        time_finished,
        time_of_day,
        completed,
        completed_on_time ?? 0,
        id,
      ]);
      return updatedTask.rows[0];
    },
    deleteTask: async (_, args) => {
      const { id } = args;
      const results = await db.query(
        "DELETE FROM tasks WHERE id = $1 RETURNING *;",
        [id]
      );
      const deletedTask = results.rows[0]
      return deletedTask;
    },
    completeTask: async (_, args) => {
      const { id, onTime } = args;

      const completedTask = await db.query(
        "UPDATE tasks SET completed = true, completed_on_time = $1 WHERE id = $2 RETURNING *;",
        [onTime ? 1 : 0, id]
      );
      return completedTask.rows[0]
    },
    pushTask: async (_, args) => {
      const { id, newStartTime, newEndTime, newTimeOfDay } = args;
      console.log('newTimeOfDay', newTimeOfDay)
      const updatedTask = await db.query("UPDATE tasks SET time_start = $1, time_finished = $2, time_of_day = $3 WHERE id = $4 RETURNING *;",
        [newStartTime, newEndTime, newTimeOfDay, id])
      return updatedTask.rows[0]
    },
  },
};

module.exports = { typeDefs, resolvers };
